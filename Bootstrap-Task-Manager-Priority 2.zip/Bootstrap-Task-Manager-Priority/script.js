// Priority Color Change Logic

document.querySelectorAll(".priority-select").forEach(select => {
    select.addEventListener("change", function() {
        const card = this.closest(".task-card");

        if (this.value === "URGENT") {
            card.classList.add("bg-danger", "text-white");
        } else {
            card.classList.remove("bg-danger", "text-white");
        }
    });
});
