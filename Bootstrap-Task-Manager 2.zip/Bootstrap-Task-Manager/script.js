document.getElementById("taskForm").addEventListener("submit", function(event) {
    event.preventDefault();

    let isValid = true;

    const fields = [
        { id: "name", message: "Task name is required." },
        { id: "description", message: "Description is required." },
        { id: "assignedTo", message: "Assigned To is required." },
        { id: "dueDate", message: "Due date is required." },
        { id: "status", message: "Please select a status." }
    ];

    fields.forEach(field => {
        const input = document.getElementById(field.id);
        const errorDiv = input.nextElementSibling;

        if (!input.value.trim()) {
            input.classList.add("is-invalid");
            errorDiv.textContent = field.message;
            isValid = false;
        } else {
            input.classList.remove("is-invalid");
            errorDiv.textContent = "";
        }
    });

    if (isValid) {
        alert("Task added successfully!");
        this.reset();
    }
});
